fn main() {
    println!("No network");
}