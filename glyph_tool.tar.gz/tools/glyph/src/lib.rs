use nom::{
    IResult,
    bytes::complete::{tag, take_while1, take_while},
    character::complete::{space0, newline, multispace0},
    branch::alt,
    combinator::{opt, map},
    multi::many0,
    sequence::preceded,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Spec {
    pub name: String,
    pub intent: String,
    pub entities: Vec<Entity>,
    pub dependencies: Vec<String>,
    pub questions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entity {
    pub name: String,
    pub contract: Option<String>,
    pub guarantees: Vec<String>,
    pub exclusions: Vec<String>,
    pub assumptions: Vec<String>,
}

pub fn parse_glyph(input: &str) -> IResult<&str, Spec> {
    let (input, _) = multispace0(input)?;
    let (input, name) = preceded(tag("#"), parse_name)(input)?;
    let (input, _) = newline(input)?;
    let (input, intent) = preceded(tag("^"), parse_text)(input)?;
    let (input, _) = newline(input)?;
    let (input, (entities, dependencies, questions)) = parse_body(input)?;
    Ok((input, Spec { name, intent, entities, dependencies, questions }))
}

fn parse_name(input: &str) -> IResult<&str, String> {
    let (input, name) = take_while1(|c: char| c.is_alphanumeric() || c == '_')(input)?;
    Ok((input, name.to_string()))
}

fn parse_text(input: &str) -> IResult<&str, String> {
    let (input, text) = take_while(|c| c != '\n' && c != '\r')(input)?;
    Ok((input, text.trim().to_string()))
}

fn parse_body(input: &str) -> IResult<&str, (Vec<Entity>, Vec<String>, Vec<String>)> {
    let mut entities = Vec::new();
    let mut dependencies = Vec::new();
    let mut questions = Vec::new();
    let mut remaining = input;
    loop {
        let (rem, line) = opt(parse_line)(remaining)?;
        remaining = rem;
        match line {
            Some(Line::Entity(e)) => entities.push(e),
            Some(Line::Dep(d)) => dependencies.push(d),
            Some(Line::Question(q)) => questions.push(q),
            None => break,
        }
    }
    Ok((remaining, (entities, dependencies, questions)))
}

#[derive(Debug)]
enum Line {
    Entity(Entity),
    Dep(String),
    Question(String),
}

fn parse_line(input: &str) -> IResult<&str, Line> {
    alt((
        map(parse_entity_block, Line::Entity),
        map(preceded(tag(">"), preceded(space0, parse_name)), Line::Dep),
        map(preceded(tag("?"), preceded(space0, parse_text)), Line::Question),
    ))(input)
}

#[derive(Debug)]
enum IndentedLine {
    Contract(String),
    Guarantee(String),
    Exclusion(String),
    Assumption(String),
}

fn parse_indented_line(input: &str) -> IResult<&str, IndentedLine> {
    let (input, _) = tag("  ")(input)?;
    alt((
        map(preceded(tag(":"), preceded(space0, parse_text)), IndentedLine::Contract),
        map(preceded(tag("!"), preceded(space0, parse_text)), IndentedLine::Guarantee),
        map(preceded(tag("-"), preceded(space0, parse_text)), IndentedLine::Exclusion),
        map(preceded(tag("~"), preceded(space0, parse_text)), IndentedLine::Assumption),
    ))(input)
}

fn parse_entity_block(input: &str) -> IResult<&str, Entity> {
    let (input, name) = preceded(tag("@"), parse_name)(input)?;
    let (input, _) = newline(input)?;
    let (input, lines) = many0(parse_indented_line)(input)?;
    let mut contract = None;
    let mut guarantees = Vec::new();
    let mut exclusions = Vec::new();
    let mut assumptions = Vec::new();
    for line in lines {
        match line {
            IndentedLine::Contract(c) => contract = Some(c),
            IndentedLine::Guarantee(g) => guarantees.push(g),
            IndentedLine::Exclusion(e) => exclusions.push(e),
            IndentedLine::Assumption(a) => assumptions.push(a),
        }
    }
    Ok((input, Entity { name, contract, guarantees, exclusions, assumptions }))
}

pub fn verify(spec: &Spec, code_path: &str) -> Result<String, String> {
    // Placeholder: Parse code with syn, check for banned APIs, etc.
    // For demo, just check if code contains certain strings.
    let code = std::fs::read_to_string(code_path).map_err(|e| e.to_string())?;
    let _ast = syn::parse_file(&code).map_err(|e| e.to_string())?;
    // Check exclusions: e.g., no std::net
    if code.contains("std::net") {
        return Err("FAIL: Exclusion violated - network".to_string());
    }
    // Check guarantees: placeholder
    Ok("PASS".to_string())
}
